# team7_project2
Simulator

This program has been developed by the following team

Team7:
zms24 Zane Saul
c_c343 Cynthia Cordova

To Run the program please use the following command in linux (exclude $):

$ python team7_project1.py -i test2_bin.txt -o team7_out

You must type python team7_project1.py

then use -i followed by the custum input file
then use -o followed by the custom output file