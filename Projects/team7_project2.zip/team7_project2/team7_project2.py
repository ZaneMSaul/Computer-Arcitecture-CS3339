import sys
import os
from collections import namedtuple

global isBreak
global inputFileName
global outputFileName
isBreak = False


class Disassemble:
    format = ""
    line = ""
    opCode = ""
    instruction = ""
    legString = ""
    ALUImmediate = 0
    address = 0
    altAddress = 0
    opWidth = 0
    shamt = 0
    op = 0
    Rt = 0
    Rm = 0
    Rn = 0
    Rd = 0

    def run(self, line, address):
        self.address = address
        self.line = line[0:32]
        self.format = self.instructionFormat(int(self.line[0:11], 2))
        self.bitCodeSlice()
        self.instruction = self.getOpInustruction()
        self.legString = self.legCode()
        self.printToFile()

    def instructionFormat(self, value):
        if value >= 160 and value <= 191:
            return "B"
        elif value == 1360 or value == 1624 or value == 1690 or value == 1691 \
                or value == 1104 or value == 1112 or value == 1872 or value == 0 \
                or value == 1692:
            return "R"
        elif value == 2038:
            return "BREAK"
        elif value == 2047:
            return "Negative Int"
        elif (value >= 1160 and value <= 1161) or (value >= 1672 and value <= 1673):
            return "I"
        elif value >= 1440 and value <= 1455:
            return "CB"
        elif (value >= 1648 and value <= 1687) or (value >= 1940 and value <= 1943):
            return "IM"
        elif value == 1984 or value == 1986:
            return "D"
        else:
            return "Error"

    def bitCodeSlice(self):
        if self.format == "B":
            self.opCode = self.line[0:6]
            self.altAddress = retInt(self.line[6:33])
            self.opWidth = 6
        elif self.format == "R":
            self.opCode = self.line[0:11]
            self.Rm = int(self.line[11:16], 2)
            self.shamt = int(self.line[16:22], 2)
            self.Rn = int(self.line[22:27], 2)
            self.Rd = int(self.line[27:33], 2)
            self.opWidth = 11
        elif self.format == "D":
            self.opCode = self.line[0:11]
            self.altAddress = retInt(self.line[11:20])
            self.op = int(self.line[20:22], 2)
            self.Rn = int(self.line[22:27], 2)
            self.Rt = int(self.line[27:33], 2)
            self.opWidth = 11
        elif self.format == "I":
            self.opCode = self.line[0:10]
            self.ALUImmediate = retInt(self.line[10:22])
            self.Rn = int(self.line[22:27], 2)
            self.Rd = int(self.line[27:33], 2)
            self.opWidth = 10
        elif self.format == "CB":
            self.opCode = self.line[0:8]
            self.altAddress = retInt(self.line[8:27])
            self.Rt = int(self.line[27:33], 2)
            self.opWidth = 8
        elif self.format == "IW":
            self.opCode = self.line[0:11]
            self.ALUImmediate = retInt(self.line[11:27])
            self.Rd = int(self.line[27:33], 2)
            self.opCode = 11
        elif self.format == "IM":
            self.Rd = int(self.line[27:33], 2)
            self.opCode = self.line[0:9]
            self.opWidth = 9
        else:
            self.opWidth = 11

    def getOpInustruction(self):
        if isBreak == True:
            return "NUM"
        elif self.opCode == "000101":
            return "B"
        elif self.opCode == "10001010000":
            return "AND"
        elif self.opCode == "10001011000":
            return "ADD"
        elif self.opCode == "1001000100":
            return "ADDI"
        elif self.opCode == "10101010000":
            return "ORR"
        elif self.opCode == "10110100":
            return "CBZ"
        elif self.opCode == "10110101":
            return "CBNZ"
        elif self.opCode == "11001011000":
            return "SUB"
        elif self.opCode == "1101000100":
            return "SUBI"
        elif self.opCode == "110100101":
            return "MOVZ"
        elif self.opCode == "111100101":
            return "MOVK"
        elif self.opCode == "11010011010":
            return "LSR"
        elif self.opCode == "11010011011":
            return "LSL"
        elif self.opCode == "11111000000":
            return "STUR"
        elif self.opCode == "11111000010":
            return "LDUR"
        elif self.opCode == "11111110110":
            return "Break"
        elif self.opCode == "11111111111":
            return "Negative Int"
        elif self.opCode == "00000000000":
            return "NOP"
        elif self.opCode == "11101010000":
            return "EOR"
        elif self.opCode == "11010011100":
            return "ASR"
        else:
            return "ERROR"

    def legCode(self):
        if self.format == "BREAK":
            global isBreak
            isBreak = True
            return "BREAK"
        elif self.format == "Negative Int":
            return self.line[0:32] + "\t" + str(self.address) + "\t" + str(int(self.line, 2) - (1 << len(self.line)))
        elif self.instruction == "NUM":
            return self.line[0:32] + "\t" + str(self.address) + "\t" + str(int(self.line, 2))
        elif self.format == "B":
            if int(self.line[6:7]):
                return self.format + "\t#" + str(int(self.line[6:32], 2) - (1 << 26))
            else:
                return self.format + "\t#" + str(int(self.line[6:32], 2))
        elif self.instruction == "NOP":
            return "NOP"
        elif self.format == "R":
            if self.instruction == "LSR" or self.instruction == "LSL" or self.instruction == "ASR":
                return self.instruction + "\t" + "R" + str(self.Rd) + ", " + "R" + str(self.Rn) + ", #" + str(
                    self.shamt)
            else:
                return self.instruction + "\t" + "R" + str(self.Rd) + ", " + "R" + str(self.Rn) + ", " + "R" + str(
                    self.Rm)
        elif self.format == "I":
            if int(self.line[10:11]):
                return self.instruction + "\t" + "R" + str(self.Rd) + ", " + "R" + str(self.Rn) + ", " + "#" + str(
                    int(self.line[self.opWidth:self.opWidth + 12], 2) - (1 << 12))
            else:
                return self.instruction + "\t" + "R" + str(self.Rd) + ", " + "R" + str(self.Rn) + ", " + "#" + str(
                    int(self.line[self.opWidth:self.opWidth + 12], 2))
        elif self.format == "CB":
            if int(self.line[8:9]):
                return self.instruction + "\t" + "R" + str(self.Rt) + ", " + "#" + str(
                    int(self.line[self.opWidth:self.opWidth + 19], 2) - (1 << 19))
            else:
                return self.instruction + "\t" + "R" + str(self.Rt) + ", " + "#" + str(
                    int(self.line[self.opWidth:self.opWidth + 19], 2))
        elif self.format == "IM":
            if self.line[self.opWidth:self.opWidth + 2] == "00":
                shift_amount = "0"
            elif self.line[self.opWidth:self.opWidth + 2] == "01":
                shift_amount = "16"
            elif self.line[self.opWidth:self.opWidth + 2] == "10":
                shift_amount = "32"
            elif self.line[self.opWidth:self.opWidth + 2] == "11":
                shift_amount = "48"
            return self.instruction + "\t" + "R" + str(self.Rd) + ", " + \
                   str(int(self.line[11:27], 2)) + ", LSL " + shift_amount
        elif self.format == "D":
            return self.instruction + "\t" + "R" + str(self.Rt) + ", " + "[R" + str(self.Rn) + ", #" + \
                   str(int(self.line[11:20], 2)) + "]"
        else:
            return self.instruction + ": opCode" + self.line[0:11] + " ;format: " + self.format

    def printToFile(self):
        outFile = open(outputFileName + "_dis.txt", "a")
        if self.format != "Negative Int" and self.instruction != "NUM":
            outFile.write(self.line[0:8] + " " + self.line[8:11] + " " \
                          + self.line[11:16] + " " + self.line[16:21] + " " + self.line[21:26] + " " \
                          + self.line[26:32] + "\t" + str(self.address) + "\t" + self.legString + "\n")
        else:
            outFile.write(self.legString + "\n")


class Register:
    register = ""
    data = 0


class Simulate:
    cycle = 1
    pc = 0
    staddress = 96
    address = staddress
    breakIndex = 0
    simList = []
    regList = []
    dataList = []

    def run(self):
        myfile = open(inputFileName, "r")
        for index in range(32):
            reg = Register()
            reg.register = "r" + str(index)
            reg.data = 0
            self.regList.append(reg)
        index = 1
        for line in myfile:
            dis = Disassemble()
            dis.run(line, self.address)
            if line[0:11] == "11111110110":
                self.breakIndex = index
            self.address += 4
            index += 1
            self.simList.append(dis)
        for instance in self.simList[self.breakIndex:]:
            if instance.line[0:1] == "1":
                self.dataList.append(int(instance.line, 2) - (1 << len(instance.line)))
            else:
                self.dataList.append(int(instance.line, 2))
        while 0 <= self.pc < len(self.simList) and self.pc < self.breakIndex + 1:
            state = State()
            state.run(self.cycle, self.simList[self.pc], self.dataList, self.breakIndex, self.simList)
            if self.simList[self.pc].line[0:11] == "11111110110":
                break
            self.cycle += 1
            self.pc += state.pc


class State:
    cycle = ""
    instance = Disassemble()
    dataList = []
    breakIndex = 0
    simList = []
    pc = 0

    def run(self, cycle, instance, dataList, breakIndex, simList):
        self.simList = simList
        self.breakIndex = breakIndex
        self.dataList = dataList
        self.instance = instance
        self.cycle = cycle
        self.process()
        self.printState()
        if self.instance.format != "B" and self.instance.format != "CB":
            self.pc = 1

    def process(self):
        if self.instance.format == "R":
            if self.instance.instruction == "LSR":
                Simulate.regList[self.instance.Rd].data = rshift(Simulate.regList[self.instance.Rn].data,
                                                                 self.instance.shamt)
            elif self.instance.instruction == "LSL":
                Simulate.regList[self.instance.Rd].data = lshift(Simulate.regList[self.instance.Rn].data,
                                                                 self.instance.shamt)
            elif self.instance.instruction == "AND":
                Simulate.regList[self.instance.Rd].data = Simulate.regList[self.instance.Rn].data & Simulate.regList[
                    self.instance.Rm].data
            elif self.instance.instruction == "ADD":
                Simulate.regList[self.instance.Rd].data = Simulate.regList[self.instance.Rn].data + Simulate.regList[
                    self.instance.Rm].data
            elif self.instance.instruction == "ORR":
                Simulate.regList[self.instance.Rd].data = Simulate.regList[self.instance.Rn].data | Simulate.regList[
                    self.instance.Rm].data
            elif self.instance.instruction == "SUB":
                Simulate.regList[self.instance.Rd].data = Simulate.regList[self.instance.Rn].data - Simulate.regList[
                    self.instance.Rm].data
            elif self.instance.instruction == "EOR":
                Simulate.regList[self.instance.Rd].data = Simulate.regList[self.instance.Rn].data ^ Simulate.regList[
                    self.instance.Rm].data
            elif self.instance.instruction == "ASR":
                Simulate.regList[self.instance.Rd].data = ashiftR(Simulate.regList[self.instance.Rn].data,
                                                                  self.instance.shamt)
        elif self.instance.format == "I":
            if int(self.instance.line[10:11]):
                immediate = int(self.instance.line[self.instance.opWidth:self.instance.opWidth + 12], 2) - (1 << 12)
            else:
                immediate = int(self.instance.line[self.instance.opWidth:self.instance.opWidth + 12], 2)
            if self.instance.instruction == "ADDI":
                Simulate.regList[self.instance.Rd].data = Simulate.regList[self.instance.Rn].data + immediate
            if self.instance.instruction == "SUBI":
                Simulate.regList[self.instance.Rd].data = Simulate.regList[self.instance.Rn].data - immediate
        elif self.instance.format == "B":
            self.pc += self.instance.altAddress
        elif self.instance.format == "CB":
            if self.instance.instruction == "CBNZ":
                if Simulate.regList[self.instance.Rt].data != 0:
                    self.pc += self.instance.altAddress
            if self.instance.instruction == "CBZ":
                if Simulate.regList[self.instance.Rt].data == 0:
                    self.pc += self.instance.altAddress
        elif self.instance.format == "IM":
            if self.instance.line[self.instance.opWidth:self.instance.opWidth + 2] == "00":
                shift_amount = 0
            elif self.instance.line[self.instance.opWidth:self.instance.opWidth + 2] == "01":
                shift_amount = 16
            elif self.instance.line[self.instance.opWidth:self.instance.opWidth + 2] == "10":
                shift_amount = 32
            elif self.instance.line[self.instance.opWidth:self.instance.opWidth + 2] == "11":
                shift_amount = 48
            if self.instance.instruction == "MOVZ":
                Simulate.regList[self.instance.Rd].data = lshift(int(self.instance.line[11:27], 2), shift_amount)
            else:
                Simulate.regList[2].data = lshift(int(self.instance.line[11:27], 2), shift_amount)
        elif self.instance.format == "D":
            if self.instance.instruction == "LDUR":
                Simulate.regList[self.instance.Rt].data = self.dataList[
                    ((Simulate.regList[self.instance.Rn].data + int(self.instance.dTAddress, 2) * \
                      4 - self.simList[self.breakIndex - 1].address) / 4) - 1]
            if self.instance.instruction == "STUR":
                while (len(self.dataList) < (Simulate.regList[self.instance.Rn].data + int(self.instance.dTAddress, 2) *
                                             4 - self.simList[self.breakIndex - 1].address) / 4):
                    for index in range(8):
                        self.dataList.append(0)
                self.dataList[((Simulate.regList[self.instance.Rn].data + int(self.instance.dTAddress, 2) * \
                                4 - self.simList[self.breakIndex - 1].address) / 4) - 1] = Simulate.regList[
                    self.instance.Rt].data

    def printState(self):
        outSim = open(outputFileName + "_sim.txt", "a")
        for index in range(21):
            outSim.write("=")
        outSim.write("\ncycle:" + str(self.cycle) + "\t" + str(self.instance.address) + "\t" + self.instance.legString \
                     + "\n" + "\nregisters:\n" + "r00:\t")
        for index in range(8):
            outSim.write(str(Simulate.regList[index].data) + "\t")
        outSim.write("\n" + "r08: \t")
        for index in range(8, 16):
            outSim.write(str(Simulate.regList[index].data) + "\t")
        outSim.write("\n" + "r16: \t")
        for index in range(16, 24):
            outSim.write(str(Simulate.regList[index].data) + "\t")
        outSim.write("\n" + "r24: \t")
        for index in range(16, 24):
            outSim.write(str(Simulate.regList[index].data) + "\t")
        outSim.write("\n" + "\ndata:")
        if self.dataList:
            index = 0
            for data in self.dataList:
                if index == 0 or index % 8 == 0:
                    outSim.write("\n" + str((Simulate.simList[self.breakIndex - 1].address + index * 4) + 4) + ":\t")
                outSim.write(str(data) + "\t")
                index += 1
        outSim.write("\n\n")


def rshift(val, n):
    return (val % 0x100000000) >> n


def lshift(val, n):
    return (val % 0x100000000) << n


def ashiftR(val, n):
    if bin(val)[0:1] == "-":
        newBin = bin(val)[3:len(bin(val)[3:]) - n + 3]
        shiftBIn = "-0b"
        for i in range(n):
            shiftBIn = shiftBIn + "1"
        newBin = shiftBIn + newBin
        return int(newBin, 2)
    else:
        newBin = bin(val)[2:len(bin(val)[2:]) - n + 2]
        shiftBIn = "0b"
        for i in range(n):
            shiftBIn = shiftBIn + "1"
        newBin = shiftBIn + newBin
        return retInt(newBin)


def retInt(bin):
    if int(bin[0:1]):
        return int(bin, 2) - (1 << len(bin))
    else:
        return int(bin, 2)


for i in range(len(sys.argv)):
    if (sys.argv[i] == '-i' and i < (len(sys.argv) - 1)):
        inputFileName = sys.argv[i + 1]
        print inputFileName
    elif (sys.argv[i] == '-o' and i < (len(sys.argv) - 1)):
        outputFileName = sys.argv[i + 1]
        print outputFileName + "_dis.txt"
        print outputFileName + "_sim.txt"
if __name__ == "__main__":
    Simulate().run()
